how to create the BANKING SYSTEM using JAVA SWINGS & MYSQL Database in just three hours, This is Part#01 of the Banking System.

Project Modules: There are 5 modules in this Banking System project.
1- Login page and Register Page
2- Add Account Balance
3- Online Utility Bill Payment
4- Instant Payment Transfer
5- Order Cheque Book

Technologies Used: We have used the following technologies in this project
Programming Language: JAVA 
IDE: NETBEANS 8.2 (APACHE NETBEANS can also be used)
DBMS: MYSQL (APACHE XAMPP)

------------------------------------------------------------------------------------------
For Promotions and Collaborations: 
Email Us: tuitionstonight@gmail.com
-------------------------------------------------------------------------------------------
Follow me on:
Instagram: https://www.instagram.com/tuitionstonight/
Instagram: https://www.instagram.com/muhammad_taha_azam/
facebook: https://www.facebook.com/TT7.in/?modal=admin_todo_tour
------------------------------------------------------------------------------------------